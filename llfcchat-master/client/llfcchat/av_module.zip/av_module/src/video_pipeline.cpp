#include "video_pipeline.h"
#include "v4l2_capturer.h"
#include "rtp_session.h"

namespace avcall {

VideoPipeline::VideoPipeline(QObject *parent)
    : QObject(parent)
{
}

VideoPipeline::~VideoPipeline()
{
    stop();
}

void VideoPipeline::setRtpSession(RtpSession *rtp)
{
    m_rtp = rtp;
}

bool VideoPipeline::start(const QString &device, int w, int h, int fps)
{
    if (m_cap)
        return true;

    m_fps    = qMax(1, fps);
    m_sendTs = 0;
    m_recvTs = 0;
    m_recvBuf.clear();

    m_cap = new V4L2Capturer(this);
    connect(m_cap, &V4L2Capturer::frameCaptured, this, &VideoPipeline::onCaptured);
    connect(m_cap, &V4L2Capturer::logMessage,    this, &VideoPipeline::logMessage);
    m_cap->startCapture(device, w, h, fps);
    return true;
}

void VideoPipeline::stop()
{
    if (!m_cap)
        return;

    m_cap->stopCapture();
    delete m_cap;
    m_cap = nullptr;
    m_recvBuf.clear();
}

void VideoPipeline::onCaptured(QByteArray mjpeg)
{
    // Send via RTP
    if (m_rtp && !mjpeg.isEmpty()) {
        const uint32_t tick = static_cast<uint32_t>(90000 / m_fps);
        m_sendTs += tick;
        m_rtp->sendVideo(mjpeg, m_sendTs);
    }

    // Decode for local preview
    QImage img = decodeMjpeg(mjpeg);
    if (!img.isNull())
        emit localFrameReady(img);
}

void VideoPipeline::onRemoteVideoPacket(QByteArray payload, uint32_t ts, bool marker, uint16_t /*seq*/)
{
    if (payload.isEmpty())
        return;

    // New timestamp → new frame
    if (m_recvBuf.isEmpty()) {
        m_recvTs = ts;
    } else if (ts != m_recvTs) {
        m_recvBuf.clear();
        m_recvTs = ts;
    }

    m_recvBuf.append(payload);

    if (marker) {
        QImage img = decodeMjpeg(m_recvBuf);
        m_recvBuf.clear();
        if (!img.isNull())
            emit remoteFrameReady(img);
    }
}

QImage VideoPipeline::decodeMjpeg(const QByteArray &data)
{
    if (data.isEmpty())
        return QImage();

    QImage img = QImage::fromData(
        reinterpret_cast<const uchar *>(data.constData()), data.size(), "JPG");
    if (img.isNull()) {
        // Fallback: let Qt auto-detect format
        img = QImage::fromData(
            reinterpret_cast<const uchar *>(data.constData()), data.size());
    }
    return img;
}

} // namespace avcall
